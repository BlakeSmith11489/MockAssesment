
| Blake Smith |
| :---- |
| s198050 |
| Mock Assesment, Number Guessing Game |
| Mock Assesment - Number Guessing Game Documentation |

## I. Requirments

1. Description of Problem: The purpose this application is trying to make is to guess the player's number. It is able to guess what your number is from 1 to 100; if the player decides to try and cheat it will detect the cheat but only if the player chooses the "Guess Higher" option. The system will display that you have not been playing fairly and that your number has changed and the application will close. On the other hand if the player chooses the "Guess Higher" option then the system will not detect any cheat but it will only continue to display the one number that is left. I have not found a way to stop this minor bug but the number guessing game will play as needed to despite this bug.

    - **Mock Assesment**: Number Guessing Game Mock Assesment

    - **Problem Statement** The system is using C# and is playing a number guessing game with the player. Without any problems and must not crash.

    - **Problem Specifications** The system must include, a proper way to get rid of unneeded values in an array and guess lower or higher based on what the player puts in and it should also be able to detect if the player cheats.

2. Input Information
- The system uses "1", "2", and "3" followed by the "Enter" key to progress the player further into the program.

3. Output Information
- **Game Start** Upon starting the program, the player will be greeted by an introduction from the program.
- **Number List** After pressing "Enter" from game start the list of numbers the player can choose from is displayed on the screen.
- **Asking If Ready** The system will ask if the player is ready and begin its number guessing following this display
- **Guessing The Number** The system will then begin to search for the number the player has decided and will display the number it has guessed and will ask the player if they got it correct or if they need to go higher or lower.
- **Correct Guess** If the system answers correctly then it will thank the player for playing anc it will close it self.
- **If Higher** If the system needs to guess higher it will display that it needs to guess higher and it will only guess and display the numbers above the one it guessed previously.
- **If Lower** If the system needs to guess lower it will only choose from numbers that are lower than the previous guess.
- **If Cheating** If the system catches the player cheating (Only if the player chooses the "Guess Higher" option), it will then catch the player in the cheat and then close the program.

4. User Interface Information
- **Options** The player's interface will only consist of the options "1", "2", and "3".

## II. Design

1. System Architecture

|
|:---------------
Game Start
|
|
Game start, starts at the second the player starts the executable and it displays the starting 
|
|:---------------
Number List
|
|
The program will display the lsit of numbers the player can choose from as their number
|
|:---------------
Asking The Player If Ready
|
|
After the game start is displayed and the number list is displayed the game will ask th eplayer if they are ready
| 
|:---------------
Guessing Higher and Lower
|
|
If the player tells the sytem to guess higher it will not choose from any number lower than the previous guess, and if the player tells the system to guess lower the system will not choose any number that is higher than the previous guess
|
|:--------------
If Guess Right
|
|
The system will display that it is happy it got it right and then it wil thank the player for playing and then xlose itself

## III. Object Information

**File**: Program.cs

Description: Runs the entire progam/problem/game.

**Attributes**

Name: random
Description: Randomly generates a new number from the list of numbers.
Type: Not Known (I have no clue...)

Name: numList
Decription: Creates the array and the slots needed for the numbers 1 - 100
Type: int[]

Name: max
Description: Sets the maximum value within the array when the guess lower option is picked
Type: int

Name: min
Description: Sets the minimum value within the array when the guess higher option is picked
Type: int 

Name: correct
Description: Sets correct to allow for the game to run properly and close properly
Type: bool