Number Guessing Game Instructions


1.Double click on the application named MockAssesment and the system will start and greet you.

2.Press Enter to proceed and The game will display a list of numbers for you to choose from and the ask you if you are ready to play.

3.If you are ready and have your number press enter and the game will guess your number.

4.When the system guesses you have 3 options, if it is your number press 1 and the enter and the game will be happy and then close itself after thanking you for playing, if your guessed number is higher than what the game guessed press 2 followed by enter and it will only guess numbers that are higher than its past guess, if your number is lower press 3 followed by enter and it will only guess numbers lower than its previous guess.

5.The game will eventually come down to one number and it will have guessed your number!


P.S.
If the game does catch you switching your number it will not display another number and it will display the number it should have been if you choose guess higher the game will catch you in a cheat and then close it self for your cheating  and if you say guess lower the game will be very persistent and continue to say the one number that is left.
	